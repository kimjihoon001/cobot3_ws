#!/usr/bin/env python3
"""FreeCAD 1.1.x generator for a three-quarter-shell tomato harvester.

Run with FreeCADCmd or as a FreeCAD macro.  All dimensions are millimetres.
The two inner quarter-spheres form the receiving basket.  A larger third
quarter-sphere rotates around Z and carries a replaceable stem-cutting blade.
"""

import json
import os
from pathlib import Path

import FreeCAD as App
import Part

try:
    import Mesh
except ImportError:
    Mesh = None


HERE = Path(__file__).resolve().parent
OUT = Path(os.environ.get("BASKET_CAD_OUT", HERE / "generated")).resolve()

# Primary parameters (mm)
FRUIT_DIAMETER = 86.0
FRUIT_CENTER_Z = 142.0
INNER_RADIUS = 52.0
BASKET_WALL = 3.2
BASKET_OUTER_RADIUS = INNER_RADIUS + BASKET_WALL
CUTTER_INNER_RADIUS = 59.0
CUTTER_WALL = 3.0
CUTTER_OUTER_RADIUS = CUTTER_INNER_RADIUS + CUTTER_WALL
BASKET_HINGE_X = BASKET_OUTER_RADIUS + 8.0
BASKET_HINGE_Z = FRUIT_CENTER_Z + 2.0
BASKET_OPEN_ANGLE = 60.0
CUTTER_ROTATION = 95.0
STEM_THROAT_RADIUS = 7.0
BLADE_Z = FRUIT_CENTER_Z + INNER_RADIUS + 14.0


def box_from_bounds(x0, x1, y0, y1, z0, z1):
    return Part.makeBox(
        x1 - x0, y1 - y0, z1 - z0, App.Vector(x0, y0, z0)
    )


def lower_quarter_shell(inner_radius, wall, split_axis, positive):
    """Return a solid spherical-shell quadrant below the fruit equator."""
    outer_radius = inner_radius + wall
    center = App.Vector(0, 0, FRUIT_CENTER_Z)
    shell = Part.makeSphere(outer_radius, center).cut(
        Part.makeSphere(inner_radius, center)
    )
    margin = outer_radius + 4.0
    lower = box_from_bounds(
        -margin, margin,
        -margin, margin,
        FRUIT_CENTER_Z - margin, FRUIT_CENTER_Z + 0.05,
    )
    shell = shell.common(lower)
    if split_axis == "x":
        clip = box_from_bounds(
            0 if positive else -margin,
            margin if positive else 0,
            -margin, margin,
            FRUIT_CENTER_Z - margin, FRUIT_CENTER_Z + 1.0,
        )
    else:
        clip = box_from_bounds(
            -margin, margin,
            0 if positive else -margin,
            margin if positive else 0,
            FRUIT_CENTER_Z - margin, FRUIT_CENTER_Z + 1.0,
        )
    return shell.common(clip)


def basket_quarter(side):
    """Quarter shell plus hinge barrel and a short load-carrying bridge."""
    positive = side > 0
    shell = lower_quarter_shell(
        INNER_RADIUS, BASKET_WALL, "x", positive
    )
    hinge_x = side * BASKET_HINGE_X
    barrel = Part.makeCylinder(
        6.0, 32.0,
        App.Vector(hinge_x, -16.0, BASKET_HINGE_Z),
        App.Vector(0, 1, 0),
    )
    if positive:
        bridge = box_from_bounds(
            BASKET_OUTER_RADIUS - 2.0, BASKET_HINGE_X + 2.0,
            -11.0, 11.0,
            FRUIT_CENTER_Z - 4.0, FRUIT_CENTER_Z + 4.0,
        )
    else:
        bridge = box_from_bounds(
            -BASKET_HINGE_X - 2.0, -BASKET_OUTER_RADIUS + 2.0,
            -11.0, 11.0,
            FRUIT_CENTER_Z - 4.0, FRUIT_CENTER_Z + 4.0,
        )
    return shell.fuse(bridge).fuse(barrel).removeSplitter()


def cutter_carrier():
    """Outer quarter shell, upper ring sector and blade attachment arm."""
    shell = lower_quarter_shell(
        CUTTER_INNER_RADIUS, CUTTER_WALL, "y", True
    )
    # The outer quarter is driven around the fruit-centred Z axis.
    ring_outer = Part.makeCylinder(
        CUTTER_OUTER_RADIUS + 5.0, 5.0,
        App.Vector(0, 0, FRUIT_CENTER_Z - 2.5),
    )
    ring_inner = Part.makeCylinder(
        CUTTER_INNER_RADIUS + 1.5, 5.0,
        App.Vector(0, 0, FRUIT_CENTER_Z - 2.5),
    )
    quarter_clip = box_from_bounds(
        -CUTTER_OUTER_RADIUS - 7.0, CUTTER_OUTER_RADIUS + 7.0,
        0, CUTTER_OUTER_RADIUS + 7.0,
        FRUIT_CENTER_Z - 4.0, FRUIT_CENTER_Z + 4.0,
    )
    ring_sector = ring_outer.cut(ring_inner).common(quarter_clip)
    # Arm terminates near the replaceable blade root above the tomato.
    arm = box_from_bounds(
        42.0, 55.0, -4.0, 16.0,
        FRUIT_CENTER_Z - 1.0, BLADE_Z + 2.0,
    )
    top_mount = box_from_bounds(
        37.0, 55.0, -7.0, 7.0,
        BLADE_Z - 3.0, BLADE_Z + 3.0,
    )
    return shell.fuse(ring_sector).fuse(arm).fuse(top_mount).removeSplitter()


def cutter_blade():
    """Replaceable sickle-like insert whose tip sweeps across the stem."""
    z = BLADE_Z - 1.0
    polygon = Part.makePolygon([
        App.Vector(1.5, -1.0, z),
        App.Vector(47.0, -6.0, z),
        App.Vector(52.0, -3.5, z),
        App.Vector(52.0, 3.5, z),
        App.Vector(44.0, 5.0, z),
        App.Vector(7.0, 1.2, z),
        App.Vector(1.5, -1.0, z),
    ])
    return Part.Face(polygon).extrude(App.Vector(0, 0, 2.0))


def base_frame():
    flange = box_from_bounds(-42, 42, -38, 38, 0, 8)
    left_post = box_from_bounds(
        -BASKET_HINGE_X - 7, -BASKET_HINGE_X + 7,
        18, 32, 8, BASKET_HINGE_Z + 10,
    )
    right_post = box_from_bounds(
        BASKET_HINGE_X - 7, BASKET_HINGE_X + 7,
        18, 32, 8, BASKET_HINGE_Z + 10,
    )
    # Ring guide supports the Z-axis rotating outer cutter quarter.
    guide_outer = Part.makeCylinder(
        CUTTER_OUTER_RADIUS + 7.0, 6.0,
        App.Vector(0, 0, FRUIT_CENTER_Z - 5.5),
    )
    guide_inner = Part.makeCylinder(
        CUTTER_OUTER_RADIUS + 2.0, 6.0,
        App.Vector(0, 0, FRUIT_CENTER_Z - 5.5),
    )
    guide = guide_outer.cut(guide_inner)
    return flange.fuse(left_post).fuse(right_post).fuse(guide).removeSplitter()


def add_part(doc, name, label, shape, color):
    obj = doc.addObject("PartDesign::Feature", name)
    obj.Label = label
    obj.Shape = shape
    obj.ViewObject.ShapeColor = color
    obj.ViewObject.LineColor = (0.15, 0.15, 0.15)
    return obj


def add_metadata(obj, joint_name, axis, lower, upper, closed):
    obj.addProperty("App::PropertyString", "JointName", "Kinematics")
    obj.addProperty("App::PropertyString", "JointAxis", "Kinematics")
    obj.addProperty("App::PropertyAngle", "LowerLimit", "Kinematics")
    obj.addProperty("App::PropertyAngle", "UpperLimit", "Kinematics")
    obj.addProperty("App::PropertyAngle", "ClosedPosition", "Kinematics")
    obj.JointName = joint_name
    obj.JointAxis = axis
    obj.LowerLimit = lower
    obj.UpperLimit = upper
    obj.ClosedPosition = closed


def assert_valid(name, shape):
    if shape.isNull() or not shape.isValid() or shape.Volume <= 0:
        raise RuntimeError("{} shape is invalid".format(name))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    doc = App.newDocument("QuarterBasketHarvester")

    shapes = {
        "BaseFrame": base_frame(),
        "LeftBasket": basket_quarter(-1),
        "RightBasket": basket_quarter(1),
        "OuterCutterQuarter": cutter_carrier(),
        "CutterBladeInsert": cutter_blade(),
    }
    for name, shape in shapes.items():
        assert_valid(name, shape)

    base = add_part(doc, "BaseFrame", "Fixed mounting frame",
                    shapes["BaseFrame"], (0.45, 0.47, 0.50))
    left = add_part(doc, "LeftBasket", "Left receiving quarter",
                    shapes["LeftBasket"], (0.18, 0.55, 0.22))
    right = add_part(doc, "RightBasket", "Right receiving quarter",
                     shapes["RightBasket"], (0.18, 0.55, 0.22))
    carrier = add_part(doc, "OuterCutterQuarter", "Outer rotating cutter quarter",
                       shapes["OuterCutterQuarter"], (0.18, 0.34, 0.62))
    blade = add_part(doc, "CutterBladeInsert", "Replaceable cutter blade",
                     shapes["CutterBladeInsert"], (0.78, 0.80, 0.84))

    add_metadata(left, "LeftBasketHinge", "Y", 0, BASKET_OPEN_ANGLE, 0)
    add_metadata(right, "RightBasketHinge", "Y", -BASKET_OPEN_ANGLE, 0, 0)
    add_metadata(carrier, "OuterCutterRotation", "Z", 0, CUTTER_ROTATION, 0)
    blade.addProperty("App::PropertyLink", "Carrier", "Assembly")
    blade.Carrier = carrier

    doc.addObject("App::FeaturePython", "DesignParameters")
    params = doc.getObject("DesignParameters")
    for prop, value in (
        ("FruitDiameter", FRUIT_DIAMETER),
        ("BasketInnerRadius", INNER_RADIUS),
        ("BasketWall", BASKET_WALL),
        ("CutterInnerRadius", CUTTER_INNER_RADIUS),
        ("CutterWall", CUTTER_WALL),
        ("StemThroatRadius", STEM_THROAT_RADIUS),
    ):
        params.addProperty("App::PropertyLength", prop, "Dimensions")
        setattr(params, prop, value)

    doc.recompute()
    fcstd = OUT / "quarter_basket_harvester.FCStd"
    doc.saveAs(str(fcstd))

    export_objects = [base, left, right, carrier, blade]
    Part.export(export_objects, str(OUT / "quarter_basket_harvester.step"))
    for obj in export_objects:
        Part.export([obj], str(OUT / (obj.Name + ".step")))
        if Mesh is not None:
            Mesh.export([obj], str(OUT / (obj.Name + ".stl")))

    dimensions = {
        "units": "mm",
        "fruit_diameter": FRUIT_DIAMETER,
        "fruit_center_z": FRUIT_CENTER_Z,
        "basket_inner_radius": INNER_RADIUS,
        "basket_wall": BASKET_WALL,
        "outer_cutter_inner_radius": CUTTER_INNER_RADIUS,
        "outer_cutter_wall": CUTTER_WALL,
        "basket_open_angle_each_deg": BASKET_OPEN_ANGLE,
        "outer_cutter_rotation_deg": CUTTER_ROTATION,
        "stem_throat_diameter": STEM_THROAT_RADIUS * 2.0,
        "blade_z": BLADE_Z,
        "joint_axes": {
            "LeftBasketHinge": "Y",
            "RightBasketHinge": "Y",
            "OuterCutterRotation": "Z",
        },
    }
    (OUT / "dimensions.json").write_text(
        json.dumps(dimensions, indent=2), encoding="utf-8"
    )
    print("Generated FreeCAD assembly:", fcstd)
    print("Validated solids:", ", ".join(shapes))


if __name__ == "__main__":
    main()
